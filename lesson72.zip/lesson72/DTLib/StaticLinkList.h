#ifndef STATICLINKLIST_H
#define STATICLINKLIST_H
#include "LinkList.h"
namespace DTLib
{
template<typename T,int N>
class StaticLinkList:public LinkList<T>
{
protected:
    typedef typename LinkList<T>::Node Node;//�﷨

    struct SNode : public Node
    {
       //�̳ж����� T values Node* next
        void* operator new(unsigned int size,void *loc)
        {
            (void)size;
            return loc;
        }
    };
    unsigned char m_space[sizeof(SNode)*N]; //creat a new
    int m_used[N];

    Node* creat()
    {
        SNode* ret=NULL;

        for(int i=0;i<N;i++)
        {
            if(!m_used[i])
            {
                ret=reinterpret_cast<SNode*>(m_space)+i;
                ret=new(ret)SNode();    //��ָ���Ŀռ��ڵ��ù��캯��
                m_used[i]=1;
                break;
            }
        }
        return ret;
    }
    void destory(SNode* pn)
    {
        SNode* space=reinterpret_cast<SNode*>(m_space);
        SNode* psn=dynamic_cast<SNode*>(pn);
        for(int i=0;i<N;i++)
        {
            if(pn==(space+i))
            {
                m_used[i]=0;
                psn->~SNode();
                break;
            }

        }
    }
 public:
    StaticLinkList()
    {
        for(int i=0;i<N;i++)
        {
            m_used[i]=0;
        }
    }
    int capacity()
    {
        return N;
    }

};
}
#endif // STATICLINKLIST_H
